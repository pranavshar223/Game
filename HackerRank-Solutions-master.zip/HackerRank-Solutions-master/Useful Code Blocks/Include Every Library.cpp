// Includes every standard c++ library
#include <bits/stdc++.h>
