![Screenshot_2019-12-10 Day 28 RegEx, Patterns, and Intro to Databases HackerRank](https://user-images.githubusercontent.com/45221397/70522940-0608a500-1b68-11ea-94b2-5955fbaa83cc.png)

