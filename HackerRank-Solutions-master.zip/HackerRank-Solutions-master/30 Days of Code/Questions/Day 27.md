![Screenshot_2019-12-10 Day 27 Testing HackerRank](https://user-images.githubusercontent.com/45221397/70520368-73660700-1b63-11ea-9dba-d3df1fdad76d.png)
