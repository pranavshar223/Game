
![Day 6](https://user-images.githubusercontent.com/45221397/68001231-459ac200-fc89-11e9-9d0c-7fe4666608db.png)
