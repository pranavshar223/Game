
![Day 4](https://user-images.githubusercontent.com/45221397/68001951-6d3f5980-fc8c-11e9-9bc4-364cc858a09c.png)
