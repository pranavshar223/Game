![Screenshot_2019-12-10 Day 26 Nested Logic HackerRank](https://user-images.githubusercontent.com/45221397/70519737-6dbbf180-1b62-11ea-865e-cd26b9433f43.png)
