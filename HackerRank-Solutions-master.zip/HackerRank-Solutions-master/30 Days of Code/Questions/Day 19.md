![Screenshot_2019-12-09 Day 19 Interfaces HackerRank](https://user-images.githubusercontent.com/45221397/70450785-54676680-1aca-11ea-96fc-5ab3eeb70ba8.png)
