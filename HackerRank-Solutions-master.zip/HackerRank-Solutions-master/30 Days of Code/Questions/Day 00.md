
![q0](https://user-images.githubusercontent.com/45221397/67614341-20b1d500-f7d9-11e9-8be8-d4f44998b48a.png)

