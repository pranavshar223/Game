![Screenshot_2019-12-10 Day 23 BST Level-Order Traversal HackerRank](https://user-images.githubusercontent.com/45221397/70516123-70b3e380-1b5c-11ea-8517-b3d4eb76b1ad.png)
