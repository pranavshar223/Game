![Screenshot_2019-12-09 Day 22 Binary Search Trees HackerRank](https://user-images.githubusercontent.com/45221397/70453165-4f0c1b00-1ace-11ea-8c67-aa7446480a5e.png)
