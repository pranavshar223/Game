![Screenshot_2019-12-09 Day 20 Sorting HackerRank](https://user-images.githubusercontent.com/45221397/70451281-16b70d80-1acb-11ea-92c2-c0c3fe7f05ab.png)
