![q2](https://user-images.githubusercontent.com/45221397/67629354-5ff42a80-f89a-11e9-9b89-2d6600931098.png)
