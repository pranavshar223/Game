![Screenshot_2019-12-09 Day 18 Queues and Stacks HackerRank](https://user-images.githubusercontent.com/45221397/70449842-b1621d00-1ac8-11ea-9f64-3562dd1e01ad.png)
