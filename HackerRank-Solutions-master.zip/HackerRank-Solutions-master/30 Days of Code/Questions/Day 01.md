![q1](https://user-images.githubusercontent.com/45221397/67614318-a8e3aa80-f7d8-11e9-9572-8f68666a96bc.png)
