![Screenshot_2019-12-10 Day 24 More Linked Lists HackerRank](https://user-images.githubusercontent.com/45221397/70515635-aefcd300-1b5b-11ea-905a-bd0fc20f07f2.png)
