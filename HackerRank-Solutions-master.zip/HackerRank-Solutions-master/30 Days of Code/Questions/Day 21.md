![Screenshot_2019-12-10 Day 21 Generics HackerRank](https://user-images.githubusercontent.com/45221397/70522512-4156a400-1b67-11ea-8f03-41f232e6a961.png)
