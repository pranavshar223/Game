![Screenshot_2019-12-10 Day 29 Bitwise AND HackerRank](https://user-images.githubusercontent.com/45221397/70523062-38b29d80-1b68-11ea-9ffd-c695216b1600.png)
