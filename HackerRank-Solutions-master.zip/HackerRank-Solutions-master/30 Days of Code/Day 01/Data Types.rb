i = 4
d = 4.0
s = 'HackerRank '
# Declare second integer, double, and String variables.

# Read and save an integer, double, and String to your variables.
num2= gets.chomp.to_i
sum= i+num2
puts "#{sum}"

# Print the sum of both integer variables on a new line.
num3= gets.chomp.to_f
sum= d+num3
puts "#{sum}"
# Print the sum of the double variables on a new line.

# Concatenate and print the String variables on a new line
name=gets.chomp
puts "#{s}" + "#{name}"




