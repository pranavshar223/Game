name = gets.chomp
puts "Hello, World.\n#{name}"
