try:
    print(int(input().strip()))
except ValueError:
    print("Bad String")
