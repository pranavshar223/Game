
a = int(input())
b = int(input())

x = a // b
y = a % b

print(x)
print(y)
print((x,y,))
